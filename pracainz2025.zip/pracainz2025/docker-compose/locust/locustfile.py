from locust import HttpUser, task, between

class Pracainz2025User(HttpUser):
    wait_time = between(0.1, 1.0)

    @task
    def load_root(self):
        self.client.get("/")
